<?php $__env->startSection('content'); ?>
    <div class="text-2xl font-medium">
        Cliquez sur login pour créer un utilisateur <a href="<?php echo e(route('login')); ?>"
            class="text-gray-900 dark:text-white hover:underline" aria-current="page">Login</a>
    </div>

    <?php echo $__env->make('layouts.message', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <div class="relative overflow-x-auto shadow-md sm:rounded-lg">
        <table class="w-full text-sm text-left rtl:text-right text-gray-500 dark:text-gray-400">
            <thead class="text-xs text-gray-700 uppercase bg-gray-50 dark:bg-gray-700 dark:text-gray-400">
                <tr>
                    <th scope="col" class="px-6 py-3">
                        Nom
                    </th>
                    <th scope="col" class="px-6 py-3">
                        Email
                    </th>
                    <th scope="col" class="px-6 py-3">
                        Rôle
                    </th>
                    <th scope="col" class="px-6 py-3">
                        Actions
                    </th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td class="px-6 py-4">
                            <?php echo e($user->name); ?>

                        </td>
                        <td class="px-6 py-4">
                            <?php echo e($user->email); ?>

                        </td>
                        <td class="px-6 py-4">
                            <?php echo e(($user->role) == '1' ? 'User' : 'Admin'); ?>

                        </td>
                        <td class="px-6 py-4">
                            <a href="<?php echo e(url('admin/edit', $user->id)); ?>">Editer</a>
                            <a href="<?php echo e(url('admin/delete', $user->id)); ?>">Supprimer</a>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\LaravelAuth\resources\views/welcome.blade.php ENDPATH**/ ?>